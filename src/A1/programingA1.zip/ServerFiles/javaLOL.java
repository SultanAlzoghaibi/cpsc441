package A1.ServerFiles;

public class javaLOL {
    public static void main(String[] args) {
        System.out.println("lol");
    }
}
